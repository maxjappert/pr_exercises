import torch


class MyLogRegNN(torch.nn.Module):

    def __init__(self):
        super(MyLogRegNN, self).__init__()
        # TODO: Define a logistic regression classifier as a neural network
        

    def forward(self, x):
        y_hat = None
        return y_hat


class MyFullyConnectedNN(torch.nn.Module):
    def __init__(self):
        super(MyFullyConnectedNN, self).__init__()
        # TODO: Define a fully connected neural network

    def forward(self, x):
        y_hat = None
        return y_hat


class MyCNN(torch.nn.Module):

    def __init__(self):
        super(MyCNN, self).__init__()
        # TODO: Define a convolutional neural network

    def forward(self, x):
        y_hat = None
        return y_hat


